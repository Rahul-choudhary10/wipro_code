package com.math.operation;

public class subtraction {

	public void sub(int a, int b) {
		int subval = a-b;
		System.out.println("Subtraction of a and b  : "+subval);
	}
}
