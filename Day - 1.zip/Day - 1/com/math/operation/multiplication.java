package com.math.operation;

public class multiplication {

	public void multiple(int a, int b) {
		int multiply = a*b;
		System.out.println("Multiplication of a and b is : "+multiply);
	}
}
