package com.math.operation;

public class addition {
	
	public void add(int a, int b) {
		int sum = a+b;
		System.out.println("Addition of a and b is : "+sum);
	}

}
